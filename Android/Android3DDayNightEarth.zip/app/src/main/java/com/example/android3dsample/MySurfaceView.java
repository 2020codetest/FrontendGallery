package com.example.android3dsample;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class MySurfaceView extends GLSurfaceView {
    private float mPreviousY;
    private float mPreviousX;
    private MyRenderer mRenderer;
    public MySurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(3);
        mRenderer = new MyRenderer(context);
        setRenderer(mRenderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float y = e.getY();
        float x = e.getX();
        switch (e.getAction()) {
            case MotionEvent.ACTION_MOVE:
                float dx = x - mPreviousX;
                float dy = y - mPreviousY;
                Earth.xAngel +=  (180 * (dy / 320));
                Earth.yAngel +=  (180 * (dx / 320));
                break;
        }

        mPreviousX = x;
        mPreviousY = y;
        return true;
    }
}
