package com.example.android3dsample;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES30;
import android.opengl.GLUtils;
import android.opengl.Matrix;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;

public class Earth {
    public static int xAngel;
    public static int yAngel;
    private int mVertexShader;
    private int mFragShader;
    private int mProgram;
    private int mPositionHandle;
    private int muMVPMatrixHandle;
    private int mLightLocationHandle;

    private int mTextHandle;
    private int mTextureId;
    private int mNightTextId;
    private int mTextureDayIdHandle;
    private int mTextureNightIdHandle;
    private void initGLScript(Context context) {
        mVertexShader = Util.loadShader(GLES30.GL_VERTEX_SHADER, Util.readFileFromAsset(context, "vertex.sh"));
        mFragShader = Util.loadShader(GLES30.GL_FRAGMENT_SHADER, Util.readFileFromAsset(context, "frag.sh"));
        mProgram = Util.createProgram(mVertexShader, mFragShader);

        mPositionHandle = GLES30.glGetAttribLocation(mProgram, "aPosition");
        mTextHandle = GLES30.glGetAttribLocation(mProgram, "aTexCoor");
        mLightLocationHandle = GLES30.glGetAttribLocation(mProgram, "aLightLocation");
        muMVPMatrixHandle = GLES30.glGetUniformLocation(mProgram, "uMVPMatrix");

        //获取白天、黑夜两个纹理引用
        mTextureDayIdHandle=GLES30.glGetUniformLocation(mProgram, "sTextureDay");
        mTextureNightIdHandle=GLES30.glGetUniformLocation(mProgram, "sTextureNight");
    }

    private FloatBuffer mVertexBuffer;
    private FloatBuffer mTexCoorBuffer;//顶点纹理坐标数据缓冲
    private int mNodeCount;
    private void initVertexData(float r) {
        //顶点坐标数据的初始化================begin============================
        final float UNIT_SIZE=0.5f;
        // 可以想象为一个圆面旋转360度形成球体
        ArrayList<Float> alVertix=new ArrayList<Float>();//存放顶点坐标的ArrayList
        final float angleSpan=10f;//将球进行单位切分的角度
        for(float vAngle=90;vAngle>-90;vAngle=vAngle-angleSpan){//垂直方向angleSpan度一份
            for(float hAngle=360;hAngle>0;hAngle=hAngle-angleSpan){//水平方向angleSpan度一份
                //纵向横向各到一个角度后计算对应的此点在球面上的坐标
                double xozLength=r*UNIT_SIZE*Math.cos(Math.toRadians(vAngle));
                float x1=(float)(xozLength*Math.cos(Math.toRadians(hAngle)));
                float z1=(float)(xozLength*Math.sin(Math.toRadians(hAngle)));
                float y1=(float)(r*UNIT_SIZE*Math.sin(Math.toRadians(vAngle)));

                xozLength=r*UNIT_SIZE*Math.cos(Math.toRadians(vAngle-angleSpan));
                float x2=(float)(xozLength*Math.cos(Math.toRadians(hAngle)));
                float z2=(float)(xozLength*Math.sin(Math.toRadians(hAngle)));
                float y2=(float)(r*UNIT_SIZE*Math.sin(Math.toRadians(vAngle-angleSpan)));

                xozLength=r*UNIT_SIZE*Math.cos(Math.toRadians(vAngle-angleSpan));
                float x3=(float)(xozLength*Math.cos(Math.toRadians(hAngle-angleSpan)));
                float z3=(float)(xozLength*Math.sin(Math.toRadians(hAngle-angleSpan)));
                float y3=(float)(r*UNIT_SIZE*Math.sin(Math.toRadians(vAngle-angleSpan)));

                xozLength=r*UNIT_SIZE*Math.cos(Math.toRadians(vAngle));
                float x4=(float)(xozLength*Math.cos(Math.toRadians(hAngle-angleSpan)));
                float z4=(float)(xozLength*Math.sin(Math.toRadians(hAngle-angleSpan)));
                float y4=(float)(r*UNIT_SIZE*Math.sin(Math.toRadians(vAngle)));
                //构建第一三角形
                alVertix.add(x1);alVertix.add(y1);alVertix.add(z1);
                alVertix.add(x2);alVertix.add(y2);alVertix.add(z2);
                alVertix.add(x4);alVertix.add(y4);alVertix.add(z4);
                //构建第二三角形
                alVertix.add(x4);alVertix.add(y4);alVertix.add(z4);
                alVertix.add(x2);alVertix.add(y2);alVertix.add(z2);
                alVertix.add(x3);alVertix.add(y3);alVertix.add(z3);
            }}

        mNodeCount = alVertix.size() / 3;
        //将alVertix中的坐标值转存到一个float数组中
        float vertices[]=new float[alVertix.size()];
        for(int i=0;i<alVertix.size();i++){
            vertices[i]=alVertix.get(i);
        }

        //创建顶点坐标数据缓冲
        ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length*4);
        vbb.order(ByteOrder.nativeOrder());//设置字节顺序
        mVertexBuffer = vbb.asFloatBuffer();//转换为float型缓冲
        mVertexBuffer.put(vertices);//向缓冲区中放入顶点数据
        mVertexBuffer.position(0);//设置缓冲区起始位置

        float[] textCordinates = generateTexCoor((int)(360/angleSpan), (int)(180/angleSpan));
        ByteBuffer cbb = ByteBuffer.allocateDirect(textCordinates.length * 4);
        cbb.order(ByteOrder.nativeOrder());
        mTexCoorBuffer = cbb.asFloatBuffer();
        mTexCoorBuffer.put(textCordinates);
        mTexCoorBuffer.position(0);
    }

    private float[] generateTexCoor(int bw,int bh){
        float[] result=new float[bw*bh*6*2];
        float sizew=1.0f/bw;//列数
        float sizeh=1.0f/bh;//行数
        int c=0;
        for(int i=0;i<bh;i++){
            for(int j=0;j<bw;j++){
                //每行列一个矩形，由两个三角形构成，共六个点，12个纹理坐标
                float s=j*sizew;
                float t=i*sizeh;//得到i行j列小矩形的左上点的纹理坐标值
                result[c++]=s;
                result[c++]=t;//该矩形左上点纹理坐标值
                result[c++]=s;
                result[c++]=t+sizeh;//该矩形左下点纹理坐标值
                result[c++]=s+sizew;
                result[c++]=t;    		//该矩形右上点纹理坐标值
                result[c++]=s+sizew;
                result[c++]=t;//该矩形右上点纹理坐标值
                result[c++]=s;
                result[c++]=t+sizeh;//该矩形左下点纹理坐标值
                result[c++]=s+sizew;
                result[c++]=t+sizeh;    //该矩形右下点纹理坐标值
            }}
        return result;
    }

    @SuppressLint("ResourceType")
    private int initTexture(Context context, boolean night)//textureId
    {
        //生成纹理ID
        int[] textures = new int[1];
        GLES30.glGenTextures
                (
                        1,          //产生的纹理id的数量
                        textures,   //纹理id的数组
                        0           //偏移量
                );
        int textureId=textures[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId);
        GLES30.glTexParameterf(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER,GLES30.GL_NEAREST);
        GLES30.glTexParameterf(GLES30.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MAG_FILTER,GLES30.GL_LINEAR);
        GLES30.glTexParameterf(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S,GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameterf(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T,GLES30.GL_CLAMP_TO_EDGE);

        //通过输入流加载图片===============begin===================
         InputStream is = context.getResources().openRawResource(night ? R.drawable.earthn : R.drawable.earth);
        Bitmap bitmapTmp;
        try
        {
            bitmapTmp = BitmapFactory.decodeStream(is);
        }
        finally
        {
            try
            {
                is.close();
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
        }
        //通过输入流加载图片===============end=====================

        //实际加载纹理
        GLUtils.texImage2D
                (
                        GLES30.GL_TEXTURE_2D,   //纹理类型
                        0, 					  //纹理的层次，0表示基本图像层，可以理解为直接贴图
                        bitmapTmp, 			  //纹理图像
                        0					  //纹理边框尺寸
                );
        bitmapTmp.recycle(); 		  //纹理加载成功后释放图片

        return textureId;
    }

    private float[] mProjMatrix = new float[16]; // 4x4 投影矩阵
    private float[] mVMatrix = new float[16]; // 摄像机位置朝向的参数矩阵
    public void initCamera(float ratio) {
        // near 面的参数值 影响会投影在near 界面
        Matrix.frustumM(mProjMatrix, 0, -ratio, ratio, -1, 1, 1, 10);
        Matrix.setLookAtM(mVMatrix, 0, 0, 0, 3, 0, 0, 0, 0, 1, 0);
    }

    private float[] getFinalMatrix(float[] matrix) {
        float[] finalMatrix = new float[16];
        Matrix.multiplyMM(finalMatrix, 0, mVMatrix, 0, matrix, 0);
        Matrix.multiplyMM(finalMatrix, 0, mProjMatrix, 0, finalMatrix, 0);
        return finalMatrix;
    }

    public void init(Context context) {
        mTextureId = initTexture(context, false);
        mNightTextId = initTexture(context, true);
        initGLScript(context);
        initVertexData(2.0f);
    }

    public void draw() {
        GLES30.glEnable(GLES30.GL_CULL_FACE);
        GLES30.glUseProgram(mProgram);
        float[] mTransformMatrix = new float[16];
        Matrix.setRotateM(mTransformMatrix, 0, 0, 0, 1, 0);
        Matrix.translateM(mTransformMatrix, 0, 0, 0, 0);
        Matrix.rotateM(mTransformMatrix, 0, yAngel, 0, 1, 0);
        Matrix.rotateM(mTransformMatrix, 0, xAngel, 1, 0, 0);
        GLES30.glUniformMatrix4fv(muMVPMatrixHandle, 1, false, getFinalMatrix(mTransformMatrix), 0);
        GLES30.glVertexAttribPointer(mPositionHandle,
                3,
                GLES30.GL_FLOAT,
                false,
                3 * 4,
                mVertexBuffer);
        GLES30.glEnableVertexAttribArray(mPositionHandle);
        //将顶点纹理坐标数据传送进渲染管线
        GLES30.glVertexAttribPointer
                (
                        mTextHandle,
                        2,
                        GLES30.GL_FLOAT,
                        false,
                        2*4,
                        mTexCoorBuffer
                );
        GLES30.glEnableVertexAttribArray(mTextHandle);//启用顶点纹理坐标数据

        GLES30.glVertexAttrib3f(mLightLocationHandle, 0, 0, 6);

        //绑定纹理
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);//设置使用的纹理编号
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mTextureId);//绑定指定的纹理id

        GLES30.glActiveTexture(GLES30.GL_TEXTURE1);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mNightTextId);//绑定指定的纹理id

        GLES30.glUniform1i(mTextureDayIdHandle, 0);//通过引用指定白天纹理
        GLES30.glUniform1i(mTextureNightIdHandle, 1);  //通过引用指定黑夜纹理

        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, mNodeCount);
    }
}
