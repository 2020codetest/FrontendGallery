package com.example.android3dsample;

import android.content.Context;
import android.opengl.GLES30;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Util {
    public static String readFileFromAsset(Context context, String assetName) {
        try {
            InputStream stream = context.getAssets().open(assetName);
            InputStreamReader sr = new InputStreamReader(stream, "utf-8");
            BufferedReader reader = new BufferedReader(sr);
            StringBuilder sb = new StringBuilder();
            String line;
            while((line = reader.readLine()) != null) {
                // make sure to add line separator
                // or there is compilation error that is hard to find
                sb.append(line).append(System.lineSeparator());
            }

            return sb.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }


    public static int loadShader(int shaderType, String source) {
        int shader = GLES30.glCreateShader(shaderType);
        GLES30.glShaderSource(shader, source);
        GLES30.glCompileShader(shader);
        return shader;
    }

    public static int createProgram(int vertexShader, int fragShader) {
        int program = GLES30.glCreateProgram();
        GLES30.glAttachShader(program, vertexShader);
        GLES30.glAttachShader(program, fragShader);
        GLES30.glLinkProgram(program);
        return program;
    }
}
