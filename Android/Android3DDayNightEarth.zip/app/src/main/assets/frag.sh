#version 300 es
precision mediump float;
uniform sampler2D sTextureDay;//纹理内容数据
uniform sampler2D sTextureNight;
in vec2 vTextureCoord; //接收从顶点着色器过来的参数
in vec2 vNight;
out vec4 fragColor;

void main()
{
   //进行纹理采样
   vec4 nightColor = texture(sTextureNight, vTextureCoord);
   vec4 dayColor = texture(sTextureDay, vTextureCoord);
   if (vNight.x > 1.f) {
    fragColor = dayColor;
   }
   else if (vNight.x > 0.f) {
    fragColor = 0.5f * nightColor + 0.5f * dayColor;
   }
   else {
    fragColor = nightColor;
   }
}