#version 300 es
uniform mat4 uMVPMatrix; //总变换矩阵
in vec3 aPosition;  //顶点位置
in vec2 aTexCoor;    //顶点纹理坐标
in vec3 aLightLocation;
out vec2 vTextureCoord;  //用于传递给片元着色器的out变量
out vec2 vNight;

// 需要定义散射光 计算球面的位置
float isNight(in vec3 pos) {
  vec3 vp= normalize(aLightLocation - pos);
  vec3 norm = normalize(pos);
  float nDotViewPosition=max(0.0,dot(norm,vp)); 	//求法向量与vp的点积与0的最大值
  if (nDotViewPosition > 0.55f) {
    return 2.f;
  } else if (nDotViewPosition > 0.f){
    return 1.f;
  } else{
    return 0.f;
  }
}

void main()
{
  vec4 pos = uMVPMatrix * vec4(aPosition,1);
   gl_Position =  pos; //根据总变换矩阵计算此次绘制此顶点位置
   vTextureCoord = aTexCoor;//将接收的纹理坐标传递给片元着色器
   float nightFactor = isNight(aPosition);
   vNight = vec2(nightFactor, 0.f);
}