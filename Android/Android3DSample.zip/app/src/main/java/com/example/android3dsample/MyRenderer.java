package com.example.android3dsample;

import android.content.Context;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyRenderer  implements GLSurfaceView.Renderer {
    private String readFileFromAsset(Context context, String assetName) {
        try {
            InputStream stream = context.getAssets().open(assetName);
            InputStreamReader sr = new InputStreamReader(stream, "utf-8");
            BufferedReader reader = new BufferedReader(sr);
            StringBuilder sb = new StringBuilder();
            String line;
            while((line = reader.readLine()) != null) {
                // make sure to add line separator
                // or there is compilation error that is hard to find
                sb.append(line).append(System.lineSeparator());
            }

            return sb.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    private Context context;
    public MyRenderer(Context context) {
        this.context = context;
    }

    private int loadShader(int shaderType, String source) {
        int shader = GLES30.glCreateShader(shaderType);
        GLES30.glShaderSource(shader, source);
        GLES30.glCompileShader(shader);
        int compilationStatus[] = new int[1];
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, compilationStatus, 0);
        return shader;
    }

    private int createProgram(int vertexShader, int fragShader) {
        int program = GLES30.glCreateProgram();
        GLES30.glAttachShader(program, vertexShader);
        GLES30.glAttachShader(program, fragShader);
        GLES30.glLinkProgram(program);
        int[] linkStatus = new int[1];
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, linkStatus, 0);
        return program;
    }

    private int mVertexShader;
    private int mFragShader;
    private int mProgram;
    private int mPositionHandle;
    private int mColorHandle;
    private int muMVPMatrixHandle;
    private void initGLScript(Context context) {
        mVertexShader = loadShader(GLES30.GL_VERTEX_SHADER, readFileFromAsset(context, "vertex.sh"));
        mFragShader = loadShader(GLES30.GL_FRAGMENT_SHADER, readFileFromAsset(context, "frag.sh"));
        mProgram = createProgram(mVertexShader, mFragShader);

        mPositionHandle = GLES30.glGetAttribLocation(mProgram, "aPosition");
        mColorHandle= GLES30.glGetAttribLocation(mProgram, "aColor");
        muMVPMatrixHandle = GLES30.glGetUniformLocation(mProgram, "uMVPMatrix");
    }

    private float[] mProjMatrix = new float[16]; // 4x4 投影矩阵
    private float[] mVMatrix = new float[16]; // 摄像机位置朝向的参数矩阵
    private void initCamera(float ratio) {
        Matrix.frustumM(mProjMatrix, 0, -ratio, ratio, -1, 1, 1, 10);
        Matrix.setLookAtM(mVMatrix, 0, 0, 0, 3, 0, 0, 0, 0, 1, 0);
    }

    private float[] getFinalMatrix(float[] matrix) {
        float[] finalMatrix = new float[16];
        Matrix.multiplyMM(finalMatrix, 0, mVMatrix, 0, matrix, 0);
        Matrix.multiplyMM(finalMatrix, 0, mProjMatrix, 0, finalMatrix, 0);
        return finalMatrix;
    }

    private FloatBuffer mVertexBuffer;
    private FloatBuffer mColorBuffer;
    private void initVertexData() {
        float UNIT_SIZE = 0.2f;
        float vertices[] = new float[] {
                -4 * UNIT_SIZE, 0, 0,
                0, -4 * UNIT_SIZE, 0,
                4 * UNIT_SIZE, 0, 0
        };
        ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
        vbb.order(ByteOrder.nativeOrder());
        mVertexBuffer = vbb.asFloatBuffer();
        mVertexBuffer.put(vertices);
        mVertexBuffer.position(0);

        float[] colors = new float[] {
                1, 0, 0, 0,
                0, 1, 0, 0,
                0, 0, 1, 0
        };
        ByteBuffer cbb = ByteBuffer.allocateDirect(colors.length * 4);
        cbb.order(ByteOrder.nativeOrder());
        mColorBuffer = cbb.asFloatBuffer();
        mColorBuffer.put(colors);
        mColorBuffer.position(0);
    }

    private void draw() {
        GLES30.glUseProgram(mProgram);
        float[] mTransformMatrix = new float[16];
        Matrix.setRotateM(mTransformMatrix, 0, 0, 0, 1, 0);
        Matrix.translateM(mTransformMatrix, 0, 0, 0, 1);
        Matrix.rotateM(mTransformMatrix, 0, 2, 0, 0, 1);
        GLES30.glUniformMatrix4fv(muMVPMatrixHandle, 1, false, getFinalMatrix(mTransformMatrix), 0);
        GLES30.glVertexAttribPointer(mPositionHandle,
                3,
                GLES30.GL_FLOAT,
                false,
                3 * 4,
                mVertexBuffer);
        GLES30.glVertexAttribPointer(mColorHandle,
                4,
                GLES30.GL_FLOAT,
                false,
                4*4,
                mColorBuffer);
        GLES30.glEnableVertexAttribArray(mPositionHandle);
        GLES30.glEnableVertexAttribArray(mColorHandle);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
    }

    @Override
    public void onSurfaceCreated(GL10 gl10, EGLConfig eglConfig) {
        GLES30.glClearColor(0, 0, 0, 1.0f);
        initGLScript(context);
        initVertexData();
    }

    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES30.glViewport(0, 0, width, height);
        initCamera((float)width / height);
    }

    @Override
    public void onDrawFrame(GL10 gl10) {
        GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT | GLES30.GL_COLOR_BUFFER_BIT);
        draw();
    }
}
