package com.example.android3dsample;

import android.content.Context;
import android.opengl.GLSurfaceView;

public class MySurfaceView extends GLSurfaceView {
    public MySurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(3);
        setRenderer(new MyRenderer(context));
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
}
